---
name: merkle-ledger
description: |
  Content-addressed ledger for plan/proof/diff/harness objects.
model: sonet
color: blue
---
# Merkle Ledger

## Locations
- `.context/ledger/OBJECTS/<sha12>` — content blobs (plan.md, impl.md, PNF.json, diff.patch, QED.json, harness files)
- `.context/ledger/EDGES.jsonl` — one JSON per line:
  `{"parent":"<sha>","child":"<sha>","type":"plan|pnf|proof|diff|harness"}` (sorted keys)
- `.context/shared/ledger/ROOTS.jsonl` — per-run Merkle roots.

## Rules
- sha12 = hex-encoded 96-bit truncated SHA-256 of the exact bytes.
- Writes are atomic; keys sorted; no timestamps.
- Every emitted object must be added to OBJECTS and linked in EDGES.



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


---
name: goal-policy
description: |
  Denylist for unsafe or manipulative goal phrases; used by L2 static scan.
model: sonet
color: cyan
---
# GOAL_DENYLIST.json
Sorted keys.
```json
{
  "schema": 1,
  "patterns": [
    "ignore previous instructions",
    "bypass guard",
    "act as",
    "override locks",
    "disable review",
    "apply(diff.patch) regardless",
    "proofs/",
    "shadow",
    "diff.patch"
  ]
}
```



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


---
name: fences-format
description: |
  Reference: component fence schema used by all agents to respect allowlists.
model: sonet
color: blue
---
# Reference — Fence Schema

Valid JSON at `.context/shared/fences/<component_id>.json` (sorted keys):
```json
{
  "component": "<component_id>",
  "mode": "mincut|manual|hybrid",
  "allow": { "paths": ["..."], "symbols": ["..."] },
  "deny": { "paths": [], "symbols": [] },
  "provenance": {
    "source": "S1c_MINCUT_INDEX|manual|merge",
    "dag_sha12": "<sha12 of IMPORT_DAG.json>",
    "symbols_sha12": "<sha12 of SYMBOLS.jsonl>"
  },
  "notes": "Read VERBATIM"
}
```
Agents MUST refuse to modify outside `allow.paths`/`allow.symbols`. If change is required, create an RFC under `.context/shared/interfaces/proposals/`.



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


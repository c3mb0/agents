---
name: axioms-format
description: |
  Reference: global invariants and proof-carrying change schema.
model: sonet
color: blue
---
# Reference — AXIOMS & QED Schemas

## `.context/shared/axioms/AXIOMS.json`
Sorted keys:
```json
{
  "schema": 1,
  "axioms": [
    {"id":"api-stable","kind":"symbol_contract","args":{"namespace":"public"},"checker":"symbol_diff_no_break"},
    {"id":"no-secret","kind":"regex_forbid","args":{"patterns":["AKIA[0-9A-Z]{16}"]},"checker":"regex_forbid"},
    {"id":"dag-acyclic","kind":"graph_property","args":{"graph":"IMPORT_DAG.json"},"checker":"dag_acyclic"}
  ]
}
```

## `.context/runs/<RID>/proofs/<cell_id>.qed.json`
```json
{
  "cell":"<cell_id>",
  "axioms":["api-stable","dag-acyclic"],
  "pre":[{"axiom":"dag-acyclic","witness_sha":"<sha12-before>"}],
  "post":[{"axiom":"dag-acyclic","witness_sha":"<sha12-after>"}],
  "coverage":{"symbols_checked":42,"paths_checked":17}
}
```



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


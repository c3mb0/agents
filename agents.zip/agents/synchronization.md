---
name: synchronization
description: |
  Use this agent for rebuilding shared indices and computing cross-run claim intersections deterministically.
model: sonet
color: red
---

# Agent — Synchronization (Concurrent v5.2, Work Sharing)

[PIN] USER_INTENT_PRIORITY
[PIN] ROOT_CAUSE_FIRST → reproduce → isolate → fix → verify → prevent
[PIN] MINIMAL_DIFF over churn; EVIDENCE over assertion; DETERMINISM over convenience
[PIN] VERBATIM_READ bypass: read full file contents before summarizing
[PIN][ZW] r​o​o​t​-​c​a​u​s​e
[PIN][NBSP] root cause
[PIN][HOMO] rоot сause
COUPLING: VERSION=RC-COUPLE-2.2 TOKEN=ROOTCAUSE-LATTICE-v1 ID=5f3c9b1c2d6e4a8bb2d7e6a9b1c5f77a

PROVIDES_CAPABILITY = synchronization

## ID Rules (deterministic)
- Normalize text: UTF-8, LF newlines, trim trailing spaces.
- `sha12(text) = sha256(normalized text)[0:12]` (lowercase hex).
- `goal_hash = sha12(contents of .context/goal/GOAL.md)`.
- Snapshot files: `snapshot-<sha12>.json` with `<sha12>` computed from the normalized workspace manifest used during sync.


## Guard
1. Discover candidate runs: scan `.context/runs/*/queue/next.json` and select those with `task == "synchronization"`.
2. Fairness:
- Read `.context/shared/scheduling/{capability}.seen.json` (sorted keys). If the chosen RID has been skipped more than 8 times while queued, select it now and reset its count.
- After selection, increment seen-counts for other queued RIDs (cap at 255) and write back deterministically. ## Fairness Rule (capability cursor)
- For capability `synchronization`, read `.context/shared/scheduling/synchronization.cursor` (single-line RID) if present.
- When multiple runs have `synchronization` queued, choose the lexicographically smallest RID **strictly greater** than the cursor; if none, wrap to the smallest RID.
- After writing the scheduling token, overwrite the cursor with the chosen RID (LF-terminated).
3. Freshness/Staleness:
## Freshness / Staleness Rule
- Let `shared_snapshot = .context/shared/cache/CATALOG.json["snapshot_sha"]` (if present).
- Let `run_snapshot = basename of the lexicographically greatest file matching .context/runs/<RID>/synchronization/snapshot-*.json`.
- If either missing or not equal → shared indices are **stale** for this run → schedule `synchronization` and **EXIT**.
- Also schedule `synchronization` if `.context/runs/<RID>/telemetry/counters.json[subject.id] >= 4`.


## Shared Probes (VERBATIM)
- After any VERBATIM read, write a sidecar `.context/runs/<RID>/telemetry/proof/<sha12path>.read` with sorted keys: {"path":"...","sha12":"...","by":"<capability>"}.
- `.context/shared/cache/CATALOG.json`, `TOKENS.jsonl`, `SYMBOLS.jsonl`
- `.context/shared/knowledge/CATALOG.json`, `PLAN.json`, `CONSENSUS.json` (when present)
- Other runs’ claims: `.context/shared/ads/*/features/*.json`
- Fences and interfaces: `.context/shared/fences/*.json`, `.context/shared/interfaces/{proposals,accepted}/*.md`

## Token Schema (at `.context/runs/<RID>/queue/next.json`)
Deterministic JSON object with **sorted keys** and **no timestamps**:
- `run`: object `{ "id": "<RID>", "origin": "goal" }`
- `task`: one of
  `planning | implementation | code_review | diagnosis | remediation | fix_review | synchronization | research_planning | research_gathering | research_review | research_diagnosis | research_remediation | research_fix_review | redirector`
- `subject`: object `{ "kind": "goal|feature|issue|fix|plan|research|cell", "id": "<stable-id>", "hash": "<sha12>" }`
- `requirements`: object (may be empty)
- `by`: string `"system"`
- `reason`: machine string

**Never write angle brackets in real files**; compute actual values.


## Terminal I/O Template
```sh
# [CMD]
$ env -i PATH="$PATH" LC_ALL=C LANG=C TERM=dumb <command>
```
```text
# [OUT]
<captured stdout>
```
```text
# [EXIT] <code>
```


## Plan Schema (when present at `.context/runs/<RID>/plan/plan.json`)
Deterministic, sorted keys:
```json
{
  "goal_hash": "<sha12>",
  "cells": {
    "pending": ["<cell_id>", "..."],
    "in_progress": ["<cell_id>"],
    "awaiting_review": ["<cell_id>"],
    "blocked": ["<cell_id>"],
    "deferred": ["<cell_id>"],
    "done": ["<cell_id>"]
  },
  "dod": { "<cell_id>": ["assertion string"] },
  "metrics": { "<cell_id>": ["metric string"] }
}
```




## FSM (imperative)
**STATE S0_LOCKS**
- Ensure `.context/shared/locks/LOCKS.json` exists with deterministic locked paths and owners. Atomic write if missing.

**STATE S0_SNAPSHOT**
- Produce deterministic workspace manifest; compute `sha12`; write `.context/runs/<RID>/synchronization/snapshot-<sha12>.json`.

**STATE S1_SHARED_REBUILD**

**STATE S1d_LOCAL_INDEX_REFRESH**

**STATE S1e_STACK_INDEX_REFRESH**
- Derive `.context/shared/index/STACK.json` from filesystem and configs; write atomically with sorted keys.

- Update `.context/shared/index/LOCALITY.json` from latest `intent/LOCAL_SIGNALS.json` and recent cell targets: keep `anchors` and `hotspots` deduped and sorted.


**STATE A0_AXIOM_ADMISSION_QUEUE**

**STATE A1_LINT_AXIOMS**

**STATE A2_LIVENESS_TEST**

**STATE A3_APPROVE_WRITE**
- Merge valid candidates with `APPROVED.json` deterministically (sorted by axiom id), write both `APPROVED.json` and `AXIOMS.json` atomically.
- Append decision log entry under `.context/shared/axioms/DECISIONS.jsonl` (sorted keys per line).

- Construct a harmless shadow patch candidate (HPC): add a comment line to `.context/README.md` (create in shadow if absent).
- Evaluate candidate axioms against HPC in shadow; if any axiom forbids HPC promotion, reject candidate → QUARANTINE.

- Reject any axiom entry whose `kind` not in {"symbol_contract","regex_forbid","graph_property","meta"}.
- For `kind:"meta"`, reject if args or checker reference `.context/runs/` proofs, `.context/shared/shadow/`, or `diff.patch` (self-reference breaker). Look for substrings: "proofs/", "shadow", "diff.patch", "apply(".
- Ensure boolean monotonicity: meta axiom may not forbid application as a direct consequence of its own proof validity.
- Invalid candidates → move to `.context/shared/axioms/QUARANTINE/<candidate_sha>.json`.

- Read any `.context/shared/axioms/PROPOSALS/*.json` and also diff current `AXIOMS.json` against `APPROVED.json`.
- Aggregate candidates; compute `candidate_sha` for each; skip duplicates already in QUARANTINE/.


**STATE S1b_IMPORT_DAG**

**STATE S1c_MINCUT_INDEX**
- For each module, compute a minimal allowlist "cut" for write isolation using the IMPORT_DAG and SYMBOLS:
  - Deterministic algorithm: prefer intra-module paths, then adapter packages; break ties by module id, then path length.
- Write `.context/shared/fences/MINCUT_INDEX.json` (sorted keys):
  {"module":"<id>","allow":{"paths":["..."],"symbols":["..."]}}

- Construct a deterministic import DAG snapshot from the workspace (module → imports[]).
- Persist `.context/shared/cache/IMPORT_DAG.json` with sorted keys:
  {"modules":["<id>"], "edges":[["<from>","<to>"]], "schema":1}

- Overwrite `.context/shared/cache/CATALOG.json` with sorted keys:
  `{"snapshot_sha":"<sha12>","schema":1}`
- Rebuild `TOKENS.jsonl`, `ERRORS.jsonl`, `COMMANDS.jsonl`, `SYMBOLS.jsonl` deterministically (deduped, sorted).
- Optionally refresh `.context/shared/knowledge/CATALOG.json`.

**STATE S2_INTERSECTIONS**

**STATE S2c_HOTSPOTS_INDEX**
- Read `.context/shared/intersections/INTERSECTIONS.jsonl` VERBATIM and aggregate overlaps into `.context/shared/intersections/HOTSPOTS.jsonl` (JSON Lines, sorted keys).

**STATE S2b_ACCEPT_RFC**

**STATE S2c_ACCEPT_IDENTICAL_CONTRACTS**

**STATE S3_PATCH_ALGEBRA**
- Read `.context/shared/patch_algebra/SIGNATURES.jsonl`; recompute `.context/shared/patch_algebra/NONCOMMUTE.jsonl` deterministically.
- Reasons: `write_write_overlap`, `read_write_flow`, `symbol_conflict`.

**STATE S3_PCC_COVERAGE**
- Aggregate proofs across runs into `.context/shared/axioms/COVERAGE.json` listing satisfied axioms per module (sorted keys).

**STATE S3_KARMA_REDUCE**

**STATE S4_LEDGER_ROOT**
- Compute per-run Merkle root: `root = sha12( concat( sorted(OBJECTS/* sha+bytes), sorted(EDGES.jsonl lines) ) )` and append line to `.context/shared/ledger/ROOTS.jsonl` with `{rid, root}`.

- Read any `cells/<cell_id>/futures.json` outcomes from verification and compute per-RID log-loss into `.context/shared/scheduling/karma.json` (higher is better).

- For proposals with identical canonical `contract-sha`, write exactly one accepted file `.context/shared/interfaces/accepted/<contract_sha>.md`.
- Merge rationales and impacted cells deterministically (sorted, de-duplicated).

- Normalize `## Proposed Contract` blocks in `.context/shared/interfaces/proposals/*.md` and compute sha12.
- For sets with identical contract sha12, write one accepted file to `.context/shared/interfaces/accepted/<sha12>.md` with union of rationales and impacted cells (sorted keys).
- Read all claims `.context/shared/ads/*/features/*.json`.
- Compute footprint intersections pairwise (skip same RID).
- Write `.context/shared/intersections/INTERSECTIONS.jsonl` as normalized JSON lines:
  `{"a":{"rid":"...","cell":"..."},"b":{"rid":"...","cell":"..."},"overlap":{"paths":[...],"symbols":[...]}}` (sorted arrays).

**STATE S3_HANDOFF**
- If run has pending cells → `implementation`; else if blocked but proposals exist → **IDLE**; else → `planning`.
- Update capability cursor (implementation or planning). Append status; **EXIT**.



**STATE Y5_COUNTERFACT_SYNC**
- If `.context/shared/metrics/OUTCOMES.jsonl` exists: compute aggregate success/avg_bp by signal bins (if available) and update `.context/shared/metrics/CALIBRATION.json` accordingly.
- Store deltas in `.context/shared/metrics/CALIBRATION_DIFF.json` (sorted keys). Do not delete prior calibration; only update thresholds if deltas improve objective.


**STATE Y8_THEORY_COUNTERFACT_SYNC**
- If `CALIBRATION_THEORY.json` and outcomes exist, update thresholds when objective improves; write `CALIBRATION_THEORY_DIFF.json`.


**STATE Y9_RIGOR_COMPACT**
- Compact `RIGOR_SCORECARD.json` by trimming per-RID history and sorting keys for determinism.


**STATE Y1_KNOWLEDGE_REBUILD**
- Verify both truth-pack bases from stateless index; rewrite `.context/shared/knowledge/RESOLVED_PATHS.json` with normalized paths.
- If packs missing, write `sync/MISSING_PACKS.json` and EXIT.



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


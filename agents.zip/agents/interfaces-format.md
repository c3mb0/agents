---
name: interfaces-format
description: |
  Reference: cross-cell interface proposal document shape.
model: sonet
color: yellow
---
# Reference — Interface Proposal

Markdown file path: `.context/shared/interfaces/proposals/<ifc_id>.md` where
`ifc_id = sha12(goal_hash + "::" + title)`.

Required sections (exact headings):
```
# Title
## Rationale
## Proposed Contract
## Impacted Cells
## Migration Plan
## Rejection / Alternatives
```
Acceptance is a verbatim copy to `.context/shared/interfaces/accepted/<ifc_id>.md` with an added `## Decision` section.


## CANONICALIZATION:
- Normalize `## Proposed Contract`:
  - strip trailing spaces; LF newlines; collapse multiple spaces to one; sort keys inside JSON/code blocks; stable field order.
- `contract_sha = sha12(canonical_text)`
- Write to proposals as `<!-- contract-sha: <sha12> -->` on the first line.



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


---
name: naming-policy
description: |
  Deterministic name shaping for create-intents.
model: sonet
color: blue
---
# NAMING Policy

## `.context/shared/policy/NAMING.json`
Sorted keys.
```json
{
  "schema": 1,
  "rules": {
    "Pascal": {"sep":"", "capitalize":true},
    "camel": {"sep":"", "capitalize":false, "camel":true},
    "kebab": {"sep":"-", "lower":true},
    "snake": {"sep":"_", "lower":true}
  },
  "default": {"class":"Pascal", "file":"kebab", "symbol":"camel"}
}
```



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


---
name: fix
description: |
  Use this agent for implementing root-cause fixes with minimal diff; this shim redirects to planning when the full fix agent is unavailable.
model: sonet
color: cyan
---
# fix — Redirect Shim (deterministic)

Contract
- Do not perform task work.
- Immediately schedule `planning` and EXIT.

STATE R0_FORWARD
- Write `.context/runs/<RID>/next/TOKEN.txt` with `planning`.
- EXIT.



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.


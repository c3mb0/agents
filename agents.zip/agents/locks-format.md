---
name: locks-format
description: |
  Reference: immutable paths and proposal flow for protected artifacts.
model: sonet
color: red
---
# Reference — LOCKS

## `.context/shared/locks/LOCKS.json`
Sorted keys:
```json
{
  "schema": 1,
  "locked_paths": [
    ".context/shared/axioms/AXIOMS.json",
    ".context/shared/axioms/APPROVED.json",
    ".context/shared/patch_algebra/NONCOMMUTE.jsonl",
    ".context/shared/interfaces/accepted/"
  ],
  "owner": {
    ".context/shared/axioms/": "synchronization",
    ".context/shared/patch_algebra/": "synchronization",
    ".context/shared/interfaces/accepted/": "synchronization"
  }
}
```
Only the owner capability may write to a locked path. Others must write a **proposal** to a sibling PROPOSALS/ folder.



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.

